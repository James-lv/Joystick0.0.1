#!/usr/bin/env python3
import socket
import struct
from enum import IntEnum

# ===================== Axis ���� =====================
class AxisBitmask(IntEnum):
    Elevator     = 0x1
    Aileron      = 0x2
    Rudder       = 0x4
    Collective   = 0x8
    BrakesLeft   = 0x10
    BrakesRight  = 0x20
    TrimElevator = 0x40
    TrimAileron  = 0x80
    TrimRudder   = 0x100
    Throttle1    = 0x200
    Throttle2    = 0x400
    Throttle3    = 0x800
    Throttle4    = 0x1000
    SpeedBrake   = 0x2000
    NoseWheel    = 0x4000
    Seatshaker   = 0x8000


class TargetTorqueController:
   #"""���� CLS2Sim ��Ŀ�����ز��� (Target Torque)"""

    def __init__(self, ip="127.0.0.1", port=15090, timeout=8):
        self.remoteEndpoint = (ip, port)
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 5)
        self.sock.settimeout(timeout)
        self.sock.bind(('', 0))

    # ===================== UDP ����� =====================
    def build_set_target_torque_query(self, axis, torque_value: int):
        #"""��������Ŀ�����ص� UDP ����"""
        # ��ʽ: Header(0xCE) + Axis + DataID(0x28) + Int16����ֵ
        return struct.pack('<IIIh', 0xCE, axis, 0x28, torque_value)

    def sendThenReceive(self, send_data: bytes):
        self.sock.sendto(send_data, self.remoteEndpoint)
        response, _ = self.sock.recvfrom(8192)
        return response

    # ===================== ����ӿ� =====================
    def set_target_torque(self, axis_name: str, value: int):
        #"""ͨ������������Ŀ������"""
        if not (0 <= value <= 1000):
            raise ValueError("Target Torque over value")

        axis = getattr(AxisBitmask, axis_name)
        query = self.build_set_target_torque_query(axis, value)
        response = self.sendThenReceive(query)
        #print(f"[TargetTorque] {axis_name} = {value} -> response: {response}")
        return response

    def close(self):
        self.sock.close()
